from extractreq.partof_modul1 import partOf
from extractreq.partof_modul2 import wsd_partof
from extractreq.partof_modul2a import ukur_partOf_alternatif

from extractreq.usecase_modul1 import xmlParser
from extractreq.usecase_modul2 import parsingRequirement
from extractreq.usecase_modul3 import ucdReq

from extractreq.modul_ekspart import partOf
from extractreq.modul_spacySent import spacyClause
from extractreq.modul_stanfordSent import stanford_clause
import extractreq.modul_clausySent

__version__ = '0.0.2'
