from extractreq.usecase_modul1 import xmlParser
from extractreq.usecase_modul2 import parsingRequirement
from extractreq.usecase_modul3 import ucdReq

from extractreq.modul_ekspart import partOf
from extractreq.modul_spacySent import spacyClause
from extractreq.modul_stanfordSent import stanford_clause
from extractreq.modul_triplet import extractNlp